#include<htc.h>
#include<stdio.h>
#include "lcd(16).h"
//Th?ch anh ngo?i 
#define _XTAL_FREQ 4000000

// Th?ch anh n?i 
//#define _XTAL_FREQ 4000000
/*__CONFIG(FOSC_HS & WDTE_OFF & PWRTE_ON & MCLRE_OFF & CP_OFF & CPD_OFF 
 & BOREN_ON & IESO_OFF & FCMEN_OFF & LVP_OFF & DEBUG_OFF);*/


// Th?ch anh n?i 4MHz 
__CONFIG(FOSC_INTRC_NOCLKOUT & WDTE_OFF & PWRTE_ON & MCLRE_OFF & CP_OFF & CPD_OFF & BOREN_ON & IESO_OFF & FCMEN_OFF & LVP_OFF & DEBUG_OFF);

unsigned int dem;
unsigned int xung;
float v;
void main()
{
lcd_init();
ANSEL=ANSELH=0;

OSCCON = 0b01100001; // khai b�o th?ch anh n?i 4MHz
TRISA4 = 1; // input
dem = 0;
xung = 0;

T0CS = 1;   // counter
T0SE = 1;

PSA = 1;

//PS2 = 0;
//PS1 = 1;
//PS0 = 0;

T0IE = 1;
T0IF = 0;
GIE = 1;

TMR0 =5;

while(1)
{	
    __delay_ms(1000);   // Th?i gian l?y m?u( n?u kh�ng c� th� LCD s? kh�ng k?p l?y m?u v� code ch?y qu� nhanh)
    xung = dem*250 + TMR0;
    TMR0 = 5;
    dem = 0;

	lcd_gotoxy(0,0);
	printf("So xung: %04d",xung);
    v =  (xung/24)*60.0;  // delay bao nhi�u th� nh�n sao cho b?ng 1 ph�t
    lcd_gotoxy(0,1);
	printf("V=%01.2f v/ph",v);

    
}
}

void interrupt ngat()
{
	if(T0IF && T0IE)
	{
		dem++;
	}
	T0IF = 0;

}

void putch(char c)
	{lcd_putc(c);}
